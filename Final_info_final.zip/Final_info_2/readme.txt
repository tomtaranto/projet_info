1 - Vérifiez que vous possedez les fichiers suivant :
- contraintes.csv
- croisiere_planetes.csv
- croisiere_staellites.csv
- croisiere_vie.csv
- destinations.csv
- priorites.csv
- souhaits_voyageurs.csv

2 - Tapez la commande : make

3 - Puis tapez la commande : ./prog



