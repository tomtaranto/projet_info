struct listePersonnes_base {
  char** tab;
  int priorite;
  listePersonnes next;
};

struct dictDestinations_bucket {
  char* planete;
  int places;
  dictDestinations_liste next;
};

struct listeFinale_base {
  char** tab;
  listeFinale next;
};
